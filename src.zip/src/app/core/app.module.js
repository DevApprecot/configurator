(function() {
	'use strict';

	angular.module('configurator', ['ui.router', 'ngStorage', 'angular-loading-bar', 'ui.bootstrap']);

})()
